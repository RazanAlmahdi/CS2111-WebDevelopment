<div class="border-end bg-white" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-light">
				<img class="effatlogo" src="images/effatlogo.jpg" alt="Effat University">
				</div>
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="index.php">Home</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="schools.php">Shools</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="visits.php">Visits</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="newvisit.php">New Visit</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="updatevisit.php">Update Visit</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Delete Visit</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="signup.php">Sign Up</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="updateaccount.php">Update Account Info</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="logout.php">Log Out</a>
                </div>
</div>