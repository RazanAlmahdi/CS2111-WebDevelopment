 window.onload=function() {

  var title = document.getElementById("title");
    title.onkeydown = function () {
        title.style.backgroundColor = "#FFFFFF";

};

title.onkeyup = function() {
	if (title.value.trim() == ""){
	 title.style.backgroundColor = "Red";
console.log("inside title key up")
}

};

  var desc = document.getElementById("desc");

    desc.onkeydown = function () {

        desc.style.backgroundColor = "#FFFFFF";
};
   desc.onkeyup = function() {
	if (desc.value.trim() == ""){
	 desc.style.backgroundColor = "Red";

   }};
 var checkbox = document.getElementById('mycheck')
console.log(checkbox.checked)


checkbox.addEventListener('change', (event) => {
var red = document.getElementById('divisors')
  if (event.currentTarget.checked) {


red.style.backgroundColor ="#EBF4FB";



}
else
	red.style.backgroundColor ="red";


});


    title.onkeydown = function () {

        title.style.backgroundColor = "#FFFFFF";
};

  var myform = document.getElementById("mainForm");

  myform.onsubmit = function(e) {


      var allrequired = document.querySelectorAll(".required");

 console.log(allrequired.length)


 for(var i=0; i < allrequired.length; i++)
 {

	var checkbox = document.getElementById('mycheck')

	if(allrequired[i].tagName == 'DIV') {

		if (checkbox.checked == false){

          allrequired[i].style.backgroundColor = "Red";
          e.preventDefault();
		}

 }
      else if(allrequired[i].value.trim() == "")
        {
            allrequired[i].style.backgroundColor = "Red";

            e.preventDefault();
        }
    };
  };
 }
